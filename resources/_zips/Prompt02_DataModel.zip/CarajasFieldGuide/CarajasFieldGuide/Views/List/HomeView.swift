import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// HomeView.swift — updated for Prompt 02
// Wired to SpeciesStore. Confirms JSON loading with species list preview.
// ─────────────────────────────────────────────────────────────────────────────

struct HomeView: View {

    @State private var store = SpeciesStore()

    var body: some View {
        NavigationStack {
            Group {
                if store.isLoading {
                    loadingView
                } else if let error = store.loadError {
                    errorView(error)
                } else {
                    placeholderView
                }
            }
            .navigationBarHidden(true)
        }
        .background(Color.appBackground)
        .tint(Color.appPrimary)
        .task { store.load() }
    }

    private var loadingView: some View {
        ZStack {
            Color.appBackground.ignoresSafeArea()
            ProgressView().tint(Color.appPrimary)
        }
    }

    private func errorView(_ message: String) -> some View {
        ZStack {
            Color.appBackground.ignoresSafeArea()
            VStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle")
                    .font(.system(size: 32)).foregroundColor(.iucnAmber)
                Text("Could not load species data")
                    .font(.bodyMedium).foregroundColor(.onSurface)
                Text(message)
                    .font(.sourceFooter).foregroundColor(.outline)
                    .multilineTextAlignment(.center).padding(.horizontal, 32)
            }
        }
    }

    private var placeholderView: some View {
        ZStack {
            Color.appBackground.ignoresSafeArea()
            VStack(spacing: 20) {
                VStack(spacing: 6) {
                    Text("Carajás")
                        .font(.custom("Manrope-Bold", size: 32))
                        .foregroundColor(.appPrimary)
                    Text("Field Guide")
                        .font(.custom("Manrope-Medium", size: 18))
                        .foregroundColor(.onSurfaceVariant)
                }
                Divider().frame(width: 60).background(Color.outlineVariant)
                VStack(spacing: 8) {
                    Text("SNAKES · CARAJÁS")
                        .font(.sectionLabel).textCase(.uppercase)
                        .tracking(1.0).foregroundColor(.outline)

                    if store.speciesCount > 0 {
                        HStack(spacing: 6) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 13)).foregroundColor(.venomLowRisk)
                            Text("\(store.speciesCount) species loaded")
                                .font(.bodyText).foregroundColor(.onSurfaceVariant)
                        }
                        VStack(spacing: 4) {
                            ForEach(store.species.prefix(4)) { s in
                                HStack(spacing: 8) {
                                    Circle()
                                        .fill(s.venomStatus?.color ?? .outline)
                                        .frame(width: 6, height: 6)
                                    Text(s.displayName)
                                        .font(.bodyText).foregroundColor(.onSurface)
                                    Spacer()
                                    Text(s.iucnStatus?.code ?? "–")
                                        .font(.iucnBadge)
                                        .foregroundColor(s.iucnStatus?.color ?? .outline)
                                }
                            }
                            if store.speciesCount > 4 {
                                Text("+ \(store.speciesCount - 4) more")
                                    .font(.sectionLabel).foregroundColor(.outline)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                        .padding(12)
                        .background(Color.surfaceContainerLow)
                        .cornerRadius(AppRadius.medium)
                    }

                    HStack(spacing: 8) {
                        ForEach([Color.appPrimary, .appSecondary, .venomDangerous,
                                 .venomMild, .venomLowRisk, .iucnAmber], id: \.self) { c in
                            RoundedRectangle(cornerRadius: 4).fill(c).frame(width: 24, height: 24)
                        }
                    }.padding(.top, 8)

                    Text("DATA MODEL + JSON LOADED ✓")
                        .font(.sectionLabel).textCase(.uppercase)
                        .tracking(1.0).foregroundColor(.venomLowRisk)
                }
            }
            .padding(AppSpacing.pagePadding)
        }
    }
}

#Preview { HomeView() }
