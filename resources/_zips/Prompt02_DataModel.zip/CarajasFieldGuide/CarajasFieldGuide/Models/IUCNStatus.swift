import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// IUCNStatus.swift
// Carajás Field Guide
//
// Seven-state IUCN Red List classification.
// Defined in MasterDoc v0.3 Section 6.2 and Section 8.4.
//
// Colour groups:
//   LC / NT  → green  #23422a (appPrimary)
//   VU / EN  → amber  #C07820
//   CR/EW/EX → red    #ba1a1a (appError)
// ─────────────────────────────────────────────────────────────────────────────

enum IUCNStatus: String, Codable, CaseIterable {
    case lc = "LC"
    case nt = "NT"
    case vu = "VU"
    case en = "EN"
    case cr = "CR"
    case ew = "EW"
    case ex = "EX"

    // ── Badge text ────────────────────────────────────────────────────────────
    /// The acronym shown in the (XX) badge.
    /// HTML ref: font-headline font-bold text-[12px] "(LC)"
    var code: String { rawValue }

    /// Badge display with parentheses, matching HTML ref exactly.
    var badgeText: String { "(\(rawValue))" }

    // ── Full category name ────────────────────────────────────────────────────
    /// Right-aligned value in the IUCN fact row.
    var label: String {
        switch self {
        case .lc: return "Least Concern"
        case .nt: return "Near Threatened"
        case .vu: return "Vulnerable"
        case .en: return "Endangered"
        case .cr: return "Critically Endangered"
        case .ew: return "Extinct in the Wild"
        case .ex: return "Extinct"
        }
    }

    // ── Colour group ──────────────────────────────────────────────────────────
    enum ColorGroup {
        case green, amber, red
    }

    var colorGroup: ColorGroup {
        switch self {
        case .lc, .nt:       return .green
        case .vu, .en:       return .amber
        case .cr, .ew, .ex:  return .red
        }
    }

    // ── Resolved SwiftUI colour ───────────────────────────────────────────────
    /// Colour applied to both the badge text and the full label.
    var color: Color {
        switch colorGroup {
        case .green: return .iucnGreen  // #23422a
        case .amber: return .iucnAmber  // #C07820
        case .red:   return .iucnRed    // #ba1a1a
        }
    }

    // ── Row background ────────────────────────────────────────────────────────
    /// HTML ref: bg-surface-container-low/50 for all IUCN rows.
    var rowBackground: Color {
        Color.surfaceContainerLow.opacity(0.50)
    }
}
