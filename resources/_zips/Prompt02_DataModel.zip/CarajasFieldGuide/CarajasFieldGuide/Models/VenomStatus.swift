import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// VenomStatus.swift
// Carajás Field Guide
//
// Four-state venom classification system.
// Defined in MasterDoc v0.3 Section 6.2 and Section 8.3.
//
// Colour system:
//   dangerous  → red skull    #ba1a1a  human fatalities recorded
//   mild       → orange skull #C07820  side effects, no deaths
//   lowRisk    → green skull  #4A8A30  venom present, minimal human effect
//   nonVenomous → green smiley #406840 no venom
// ─────────────────────────────────────────────────────────────────────────────

enum VenomStatus: String, Codable, CaseIterable {
    case dangerous   = "dangerous"
    case mild        = "mild"
    case lowRisk     = "low_risk"
    case nonVenomous = "non_venomous"

    // ── Display label ─────────────────────────────────────────────────────────
    /// Plain-language label shown in the venom fact row.
    /// HTML ref: "Dangerously venomous", "Mildly venomous" etc.
    var label: String {
        switch self {
        case .dangerous:    return "Dangerously venomous"
        case .mild:         return "Mildly venomous"
        case .lowRisk:      return "Venomous, low risk"
        case .nonVenomous:  return "Non-venomous"
        }
    }

    // ── Icon colour ───────────────────────────────────────────────────────────
    /// Colour applied to both the skull/smiley icon and the label text.
    var color: Color {
        switch self {
        case .dangerous:    return .venomDangerous  // #ba1a1a
        case .mild:         return .venomMild        // #C07820
        case .lowRisk:      return .venomLowRisk     // #4A8A30
        case .nonVenomous:  return .venomNone        // #406840
        }
    }

    // ── Row background tint ───────────────────────────────────────────────────
    /// Subtle background tint for the venom fact row.
    /// HTML ref: bg-error-container/10 for dangerous; clear for others.
    var rowBackground: Color {
        switch self {
        case .dangerous:    return Color.errorContainer.opacity(0.10)
        case .mild:         return Color(hex: "C07820").opacity(0.06)
        case .lowRisk:      return Color(hex: "4A8A30").opacity(0.06)
        case .nonVenomous:  return Color.clear
        }
    }

    // ── SF Symbol icon name ───────────────────────────────────────────────────
    /// Icon used in the fact row. skull variants for venomous, face.smiling for non-venomous.
    var iconName: String {
        switch self {
        case .dangerous:    return "skull.fill"
        case .mild:         return "skull.fill"
        case .lowRisk:      return "skull.fill"
        case .nonVenomous:  return "face.smiling"
        }
    }
}
