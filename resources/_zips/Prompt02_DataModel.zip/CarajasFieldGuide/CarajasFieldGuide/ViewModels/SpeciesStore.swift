import SwiftUI
import Observation

// ─────────────────────────────────────────────────────────────────────────────
// SpeciesStore.swift
// Carajás Field Guide
//
// Loads and decodes species.json from the app bundle.
// Provides the full species list and the dataset maximum observation count
// used for scaling the iNaturalist visibility progress bar.
//
// Uses Swift @Observable (iOS 17+) — no ObservableObject needed.
// ─────────────────────────────────────────────────────────────────────────────

@Observable
final class SpeciesStore {

    // ── Published state ───────────────────────────────────────────────────────

    /// All species loaded from species.json. Empty until load() completes.
    private(set) var species: [Species] = []

    /// True while JSON is being decoded.
    private(set) var isLoading: Bool = false

    /// Set if decoding fails — surface in UI if needed.
    private(set) var loadError: String? = nil

    // ── Derived ───────────────────────────────────────────────────────────────

    /// Maximum iNaturalist observation count across the entire dataset.
    /// Used to scale the visibility progress bar proportionally.
    var maxObservations: Int {
        species.compactMap(\.inatObservations).max() ?? 1
    }

    /// Total number of species in the dataset.
    var speciesCount: Int { species.count }

    // ── Load ──────────────────────────────────────────────────────────────────

    /// Loads species.json from the main bundle synchronously on first call.
    /// Called from .task{} in HomeView — safe to call multiple times.
    func load() {
        guard species.isEmpty else { return }
        isLoading = true
        loadError = nil

        do {
            let loaded = try Self.loadFromBundle()
            self.species = loaded
        } catch {
            self.loadError = error.localizedDescription
            print("SpeciesStore: failed to load species.json — \(error)")
        }

        isLoading = false
    }

    // ── Bundle loading ────────────────────────────────────────────────────────

    private static func loadFromBundle() throws -> [Species] {
        guard let url = Bundle.main.url(forResource: "species", withExtension: "json") else {
            throw SpeciesStoreError.fileNotFound
        }
        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        return try decoder.decode([Species].self, from: data)
    }

    // ── Observation count helper ──────────────────────────────────────────────

    /// Returns the fractional progress (0.0–1.0) for the iNat visibility bar.
    func observationProgress(for species: Species) -> Double {
        guard let count = species.inatObservations, maxObservations > 0 else { return 0 }
        return Double(count) / Double(maxObservations)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Errors
// ─────────────────────────────────────────────────────────────────────────────

enum SpeciesStoreError: LocalizedError {
    case fileNotFound

    var errorDescription: String? {
        switch self {
        case .fileNotFound:
            return "species.json not found in app bundle. Add the file to the Xcode project with Target Membership checked."
        }
    }
}
