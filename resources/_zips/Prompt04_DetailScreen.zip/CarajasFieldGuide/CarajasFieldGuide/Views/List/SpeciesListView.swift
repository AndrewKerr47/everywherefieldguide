import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// SpeciesListView.swift
// Carajás Field Guide
//
// The Home tab species list. Searchable, image-led, minimal.
// Each row: thumbnail + common name + scientific name.
// NavigationLink to SpeciesDetailView (Prompt 04).
//
// HTML ref list screen:
//   bg-background #faf9f6
//   List title: font-headline font-medium text-[18px]
//   Subtitle: font-label 10px uppercase tracking-widest text-outline
//   Search bar: rounded-lg bg-surface-container-low
//   Row: thumbnail 44×44 radius-lg + stacked names + chevron
// ─────────────────────────────────────────────────────────────────────────────

struct SpeciesListView: View {

    let store: SpeciesStore

    @State private var searchText = ""

    // Filtered list — searches english, scientific, and local names
    var filteredSpecies: [Species] {
        guard !searchText.trimmingCharacters(in: .whitespaces).isEmpty else {
            return store.species
        }
        let query = searchText.lowercased()
        return store.species.filter {
            $0.scientificName.lowercased().contains(query) ||
            ($0.englishName?.lowercased().contains(query) ?? false) ||
            ($0.localName?.lowercased().contains(query) ?? false)
        }
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.appBackground.ignoresSafeArea()

            ScrollView {
                LazyVStack(spacing: 0, pinnedViews: []) {

                    // ── List header ───────────────────────────────────────────
                    ListHeaderView(
                        title: "Carajás snakes",
                        subtitle: "\(store.speciesCount) species · survey-confirmed"
                    )

                    // ── Search bar ────────────────────────────────────────────
                    SearchBarView(text: $searchText)
                        .padding(.horizontal, AppSpacing.pagePadding)
                        .padding(.bottom, 12)

                    // ── Species rows ──────────────────────────────────────────
                    if filteredSpecies.isEmpty {
                        emptyState
                    } else {
                        ForEach(filteredSpecies) { species in
                            NavigationLink(destination: SpeciesDetailView(species: species, store: store)) {
                                SpeciesRowView(species: species)
                            }
                            .buttonStyle(.plain)

                            // Row divider
                            if species.id != filteredSpecies.last?.id {
                                Divider()
                                    .background(Color.outlineVariant.opacity(0.3))
                                    .padding(.leading, AppSpacing.pagePadding + AppSpacing.thumbnailSize + 10)
                            }
                        }
                    }

                    // Bottom padding to clear the nav bar
                    Spacer().frame(height: AppSpacing.contentBottomPadding)
                }
            }
        }
    }

    // ── Empty search state ────────────────────────────────────────────────────

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 28))
                .foregroundColor(.outlineVariant)
            Text("No species found")
                .font(.bodyMedium)
                .foregroundColor(.onSurfaceVariant)
            Text("Try searching by common or scientific name")
                .font(.sectionLabel)
                .textCase(.uppercase)
                .tracking(1.0)
                .foregroundColor(.outline)
                .multilineTextAlignment(.center)
        }
        .padding(.top, 60)
        .padding(.horizontal, AppSpacing.pagePadding)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - List header
// ─────────────────────────────────────────────────────────────────────────────

struct ListHeaderView: View {

    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title)
                .font(.listTitle)
                .foregroundColor(.onSurface)

            Text(subtitle)
                .font(.listSubtitle)
                .textCase(.uppercase)
                .tracking(1.0)
                .foregroundColor(.outline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, AppSpacing.pagePadding)
        .padding(.top, 56) // clears status bar
        .padding(.bottom, 12)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Search bar
// ─────────────────────────────────────────────────────────────────────────────

struct SearchBarView: View {

    @Binding var text: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 13))
                .foregroundColor(.outline)

            TextField("Search species...", text: $text)
                .font(.bodyText)
                .foregroundColor(.onSurface)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 13))
                        .foregroundColor(.outline)
                }
            }
        }
        .padding(.vertical, 9)
        .padding(.horizontal, 12)
        .background(Color.surfaceContainerLow)
        .cornerRadius(AppRadius.large)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Species row
// ─────────────────────────────────────────────────────────────────────────────
// HTML ref list row:
//   flex items-center gap-[10px] padding 10px 14px
//   Thumbnail: 44×44 rounded-lg AsyncImage
//   Common name: font-body font-medium text-[13px] text-on-surface
//   Scientific name: font-body italic text-[10px] text-on-surface-variant mt-[2px]
//   Chevron right: border-right + border-top rotated 45°

struct SpeciesRowView: View {

    let species: Species

    var body: some View {
        HStack(spacing: 10) {

            // ── Thumbnail ─────────────────────────────────────────────────────
            ThumbnailView(url: species.inatImageURL)

            // ── Names ─────────────────────────────────────────────────────────
            VStack(alignment: .leading, spacing: 2) {
                Text(species.displayName)
                    .font(.listSpeciesName)
                    .foregroundColor(.onSurface)
                    .lineLimit(1)

                Text(species.scientificName)
                    .font(.listScientificName)
                    .italic()
                    .foregroundColor(.onSurfaceVariant)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)

            // ── Chevron ───────────────────────────────────────────────────────
            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(.outlineVariant)
        }
        .padding(.vertical, 10)
        .padding(.horizontal, AppSpacing.pagePadding)
        .background(Color.appBackground)
        .contentShape(Rectangle())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Thumbnail
// ─────────────────────────────────────────────────────────────────────────────

struct ThumbnailView: View {

    let url: String?

    var body: some View {
        Group {
            if let urlString = url, let imageURL = URL(string: urlString) {
                AsyncImage(url: imageURL) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    case .failure:
                        placeholderRect
                    case .empty:
                        placeholderRect
                            .overlay {
                                ProgressView()
                                    .scaleEffect(0.6)
                                    .tint(Color.outline)
                            }
                    @unknown default:
                        placeholderRect
                    }
                }
            } else {
                placeholderRect
            }
        }
        .frame(width: AppSpacing.thumbnailSize, height: AppSpacing.thumbnailSize)
        .clipShape(RoundedRectangle(cornerRadius: AppSpacing.thumbnailRadius))
    }

    private var placeholderRect: some View {
        Color.surfaceDim
    }
}
