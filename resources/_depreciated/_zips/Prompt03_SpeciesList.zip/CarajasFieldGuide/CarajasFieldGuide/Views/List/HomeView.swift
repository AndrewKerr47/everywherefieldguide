import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// HomeView.swift — updated for Prompt 03
// Replaces placeholder with live SpeciesListView.
// ─────────────────────────────────────────────────────────────────────────────

struct HomeView: View {

    @State private var store = SpeciesStore()

    var body: some View {
        NavigationStack {
            Group {
                if store.isLoading {
                    loadingView
                } else if let error = store.loadError {
                    errorView(error)
                } else {
                    SpeciesListView(store: store)
                }
            }
            .navigationBarHidden(true)
        }
        .background(Color.appBackground)
        .tint(Color.appPrimary)
        .task { store.load() }
    }

    // ── Loading ───────────────────────────────────────────────────────────────

    private var loadingView: some View {
        ZStack {
            Color.appBackground.ignoresSafeArea()
            ProgressView().tint(Color.appPrimary)
        }
    }

    // ── Error ─────────────────────────────────────────────────────────────────

    private func errorView(_ message: String) -> some View {
        ZStack {
            Color.appBackground.ignoresSafeArea()
            VStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle")
                    .font(.system(size: 32))
                    .foregroundColor(.iucnAmber)
                Text("Could not load species data")
                    .font(.bodyMedium)
                    .foregroundColor(.onSurface)
                Text(message)
                    .font(.sourceFooter)
                    .foregroundColor(.outline)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }
        }
    }
}

#Preview {
    HomeView()
}
